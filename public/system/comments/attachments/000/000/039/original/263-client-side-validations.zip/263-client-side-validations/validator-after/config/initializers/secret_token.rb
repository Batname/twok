# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
Validator::Application.config.secret_token = '542b0e0c3830d1afb1bd7943f1c535ac89047730384910e340cc8de713c49b05c8a5b4786f5af11c42d9e470ef6e996475f508d9185be8909f846356bc255695'
